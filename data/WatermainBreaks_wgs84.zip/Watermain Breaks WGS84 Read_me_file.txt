Read me file for watermain breaks wgs84


FID 		- Sequential unique whole numbers that are automatically generated.
SHAPE 		- Coordinates defining the features.
BREAK_DATE	- Date watermain break reported
BREAK_YEAR	- Year watermain break reported
XCOORD		- Easting in MTM NAD27 3 degree Projection
YCOORD		- Northing in MTM NAD27 3 degree Projection
POINT_X		- Longitude in WGS84 Coordinate System
POINT_Y		- Latitude in WGS84 Coordinate System